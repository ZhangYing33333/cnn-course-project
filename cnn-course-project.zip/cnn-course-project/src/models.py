"""CIFAR-10 ResNet-18 and three controlled variants."""
import torch
from torch import nn


def make_activation(name):
    if name == "relu":
        return nn.ReLU(inplace=True)
    if name == "gelu":
        return nn.GELU()
    raise ValueError(f"Unknown activation: {name}")


class SEBlock(nn.Module):
    def __init__(self, channels, reduction=16, activation="relu"):
        super().__init__()
        hidden = max(channels // reduction, 4)
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(nn.Linear(channels, hidden), make_activation(activation),
                                nn.Linear(hidden, channels), nn.Sigmoid())

    def forward(self, x):
        b, c, _, _ = x.shape
        scale = self.fc(self.pool(x).view(b, c)).view(b, c, 1, 1)
        return x * scale


def conv3x3(cin, cout, stride, depthwise):
    if depthwise:
        return nn.Sequential(
            nn.Conv2d(cin, cin, 3, stride, 1, groups=cin, bias=False),
            nn.Conv2d(cin, cout, 1, bias=False),
        )
    return nn.Conv2d(cin, cout, 3, stride, 1, bias=False)


class BasicBlock(nn.Module):
    def __init__(self, cin, cout, stride=1, use_se=False, depthwise=False, activation="relu"):
        super().__init__()
        self.conv1 = conv3x3(cin, cout, stride, depthwise)
        self.bn1 = nn.BatchNorm2d(cout)
        self.act1 = make_activation(activation)
        self.conv2 = conv3x3(cout, cout, 1, depthwise)
        self.bn2 = nn.BatchNorm2d(cout)
        self.se = SEBlock(cout, activation=activation) if use_se else nn.Identity()
        self.act2 = make_activation(activation)
        self.shortcut = nn.Identity() if stride == 1 and cin == cout else nn.Sequential(
            nn.Conv2d(cin, cout, 1, stride, bias=False), nn.BatchNorm2d(cout))

    def forward(self, x):
        y = self.act1(self.bn1(self.conv1(x)))
        y = self.se(self.bn2(self.conv2(y)))
        return self.act2(y + self.shortcut(x))


class CIFARResNet18(nn.Module):
    """ResNet-18 adapted for 32x32 inputs: 3x3 stem and no initial max-pool."""
    def __init__(self, num_classes=10, use_se=False, depthwise=False, activation="relu"):
        super().__init__()
        self.in_channels = 64
        self.stem = nn.Sequential(nn.Conv2d(3, 64, 3, 1, 1, bias=False),
                                  nn.BatchNorm2d(64), make_activation(activation))
        self.layer1 = self._make_layer(64, 2, 1, use_se, depthwise, activation)
        self.layer2 = self._make_layer(128, 2, 2, use_se, depthwise, activation)
        self.layer3 = self._make_layer(256, 2, 2, use_se, depthwise, activation)
        self.layer4 = self._make_layer(512, 2, 2, use_se, depthwise, activation)
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Linear(512, num_classes)

    def _make_layer(self, cout, blocks, stride, use_se, depthwise, activation):
        layers = [BasicBlock(self.in_channels, cout, stride, use_se, depthwise, activation)]
        self.in_channels = cout
        for _ in range(1, blocks):
            layers.append(BasicBlock(cout, cout, 1, use_se, depthwise, activation))
        return nn.Sequential(*layers)

    def forward(self, x):
        x = self.stem(x)
        x = self.layer1(x); x = self.layer2(x)
        x = self.layer3(x); x = self.layer4(x)
        return self.fc(self.pool(x).flatten(1))


def create_model(name, num_classes=10):
    variants = {
        "resnet18": (False, False, "relu"),
        "resnet18_se": (True, False, "relu"),
        "resnet18_dw": (False, True, "relu"),
        "resnet18_gelu": (False, False, "gelu"),
    }
    if name not in variants:
        raise ValueError(f"Unknown model {name}; choose from {', '.join(variants)}")
    se, dw, act = variants[name]
    return CIFARResNet18(num_classes, use_se=se, depthwise=dw, activation=act)


def count_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


def estimate_macs(model, input_shape=(1, 3, 32, 32)):
    total, hooks = 0, []
    def hook(layer, inputs, output):
        nonlocal total
        if isinstance(layer, nn.Conv2d):
            b, oc, oh, ow = output.shape
            kh, kw = layer.kernel_size
            total += b * oc * oh * ow * (layer.in_channels // layer.groups) * kh * kw
        elif isinstance(layer, nn.Linear):
            total += output.numel() * layer.in_features
    for layer in model.modules():
        if isinstance(layer, (nn.Conv2d, nn.Linear)):
            hooks.append(layer.register_forward_hook(hook))
    was_training = model.training
    model.eval()
    with torch.no_grad():
        model(torch.zeros(input_shape))
    for h in hooks:
        h.remove()
    model.train(was_training)
    return total
