import random
from torch.utils.data import DataLoader, Subset
from torchvision import datasets, transforms

MEAN = (0.4914, 0.4822, 0.4465)
STD = (0.2470, 0.2435, 0.2616)


def stratified_train_val_indices(labels, val_fraction=0.1, seed=42):
    """Deterministic per-class split, preserving class proportions."""
    rng = random.Random(seed)
    class_indices = {}
    for index, label in enumerate(labels):
        class_indices.setdefault(int(label), []).append(index)
    train_indices, val_indices = [], []
    for indices in class_indices.values():
        rng.shuffle(indices)
        n_val = round(len(indices) * val_fraction)
        val_indices.extend(indices[:n_val])
        train_indices.extend(indices[n_val:])
    rng.shuffle(train_indices)
    rng.shuffle(val_indices)
    return train_indices, val_indices


def make_loaders(data_dir="data", batch_size=64, workers=0, val_fraction=0.1, seed=42):
    train_tf = transforms.Compose([
        transforms.RandomCrop(32, padding=4), transforms.RandomHorizontalFlip(),
        transforms.ToTensor(), transforms.Normalize(MEAN, STD),
    ])
    eval_tf = transforms.Compose([
        transforms.ToTensor(), transforms.Normalize(MEAN, STD),
    ])
    # Two dataset objects share the same CIFAR-10 training files but use different transforms.
    train_aug = datasets.CIFAR10(data_dir, train=True, download=False, transform=train_tf)
    train_eval = datasets.CIFAR10(data_dir, train=True, download=False, transform=eval_tf)
    train_indices, val_indices = stratified_train_val_indices(
        train_aug.targets, val_fraction=val_fraction, seed=seed)
    train_set = Subset(train_aug, train_indices)
    val_set = Subset(train_eval, val_indices)
    train_loader = DataLoader(train_set, batch_size=batch_size, shuffle=True,
                              num_workers=workers, pin_memory=False)
    val_loader = DataLoader(val_set, batch_size=batch_size, shuffle=False,
                            num_workers=workers, pin_memory=False)
    return train_loader, val_loader
