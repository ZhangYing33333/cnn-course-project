import argparse
import csv
import json
import random
import time
from pathlib import Path

import numpy as np
import torch
from torch import nn

from src.data import make_loaders
from src.models import create_model, count_parameters, estimate_macs


def seed_everything(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def run_epoch(model, loader, criterion, device, optimizer=None):
    training = optimizer is not None
    model.train(training)
    loss_sum = correct = count = 0
    context = torch.enable_grad() if training else torch.no_grad()
    with context:
        for images, labels in loader:
            images, labels = images.to(device), labels.to(device)
            if training:
                optimizer.zero_grad(set_to_none=True)
            logits = model(images)
            loss = criterion(logits, labels)
            if training:
                loss.backward()
                optimizer.step()
            loss_sum += loss.item() * labels.size(0)
            correct += (logits.argmax(1) == labels).sum().item()
            count += labels.size(0)
    return loss_sum / count, correct / count


def main():
    parser = argparse.ArgumentParser(description="Train a CIFAR-10 CNN with a stratified validation split")
    parser.add_argument("--model", choices=["resnet18", "resnet18_se", "resnet18_dw", "resnet18_gelu"], default="resnet18")
    parser.add_argument("--epochs", type=int, default=20)
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--lr", type=float, default=0.1)
    parser.add_argument("--workers", type=int, default=0)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--val-fraction", type=float, default=0.1)
    parser.add_argument("--data-dir", default="data")
    parser.add_argument("--output-dir", default="outputs")
    args = parser.parse_args()
    if args.epochs < 1 or args.batch_size < 1:
        parser.error("epochs and batch-size must be positive")
    if not 0 < args.val_fraction < 1:
        parser.error("val-fraction must be between 0 and 1")

    seed_everything(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    train_loader, val_loader = make_loaders(args.data_dir, args.batch_size,
                                            args.workers, args.val_fraction, args.seed)
    model = create_model(args.model).to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.SGD(model.parameters(), lr=args.lr, momentum=0.9, weight_decay=5e-4)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)
    params, macs = count_parameters(model), estimate_macs(model)
    train_count = len(train_loader.dataset)
    val_count = len(val_loader.dataset)
    print(f"model={args.model} device={device} train_images={train_count} val_images={val_count} "
          f"parameters={params:,} MACs={macs:,}")

    rows, best_val_accuracy = [], -1.0
    best_epoch = 0
    for epoch in range(1, args.epochs + 1):
        started = time.perf_counter()
        train_loss, train_accuracy = run_epoch(model, train_loader, criterion, device, optimizer)
        val_loss, val_accuracy = run_epoch(model, val_loader, criterion, device)
        scheduler.step()
        seconds = time.perf_counter() - started
        row = {"epoch": epoch, "train_loss": train_loss, "train_accuracy": train_accuracy,
               "val_loss": val_loss, "val_accuracy": val_accuracy,
               "epoch_seconds": seconds, "learning_rate": scheduler.get_last_lr()[0]}
        rows.append(row)
        print(f"epoch {epoch:03d}/{args.epochs} train_loss={train_loss:.4f} "
              f"train_acc={train_accuracy:.4%} val_loss={val_loss:.4f} "
              f"val_acc={val_accuracy:.4%} seconds={seconds:.1f}")
        if val_accuracy > best_val_accuracy:
            best_val_accuracy, best_epoch = val_accuracy, epoch
            torch.save({"model": model.state_dict(), "model_name": args.model,
                        "epoch": epoch, "best_val_accuracy": val_accuracy,
                        "seed": args.seed, "val_fraction": args.val_fraction},
                       output_dir / f"{args.model}_best.pt")

    csv_path = output_dir / f"{args.model}_metrics.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)
    summary = {"model": args.model, "device": str(device), "epochs": args.epochs,
               "seed": args.seed, "val_fraction": args.val_fraction,
               "train_images": train_count, "val_images": val_count,
               "parameters": params, "macs_per_image": macs,
               "best_epoch": best_epoch, "best_val_accuracy": best_val_accuracy,
               "metrics_csv": str(csv_path)}
    (output_dir / f"{args.model}_summary.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8")
    print("summary:", json.dumps(summary, ensure_ascii=False))


if __name__ == "__main__":
    main()
