"""One-time final evaluation of trained checkpoints on the CIFAR-10 test split."""
import argparse
import csv
from pathlib import Path

import torch
from torch import nn
from torch.utils.data import DataLoader
from torchvision import datasets, transforms

from src.models import create_model, count_parameters, estimate_macs

MODELS = ("resnet18", "resnet18_se", "resnet18_dw", "resnet18_gelu")
MEAN = (0.4914, 0.4822, 0.4465)
STD = (0.2470, 0.2435, 0.2616)


def evaluate(model, loader, device):
    criterion = nn.CrossEntropyLoss(reduction="sum")
    loss_sum = correct = total = 0
    with torch.inference_mode():
        for images, labels in loader:
            images, labels = images.to(device), labels.to(device)
            logits = model(images)
            loss_sum += criterion(logits, labels).item()
            correct += (logits.argmax(1) == labels).sum().item()
            total += labels.size(0)
    return loss_sum / total, correct / total, total


def main():
    parser = argparse.ArgumentParser(description="Final, one-time CIFAR-10 test evaluation")
    parser.add_argument("--data-dir", default="data")
    parser.add_argument("--output-dir", default="outputs")
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--workers", type=int, default=0)
    parser.add_argument("--device", choices=("auto", "cpu", "cuda"), default="cpu")
    args = parser.parse_args()
    device = (torch.device("cuda" if torch.cuda.is_available() else "cpu")
              if args.device == "auto" else torch.device(args.device))
    if device.type == "cuda" and not torch.cuda.is_available():
        parser.error("CUDA requested but unavailable")
    transform = transforms.Compose([transforms.ToTensor(), transforms.Normalize(MEAN, STD)])
    dataset = datasets.CIFAR10(args.data_dir, train=False, download=False, transform=transform)
    loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=False,
                        num_workers=args.workers)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    print(f"final_test=CIFAR-10 official test split images={len(dataset)} device={device}")
    for name in MODELS:
        checkpoint_path = output_dir / f"{name}_best.pt"
        if not checkpoint_path.is_file():
            raise FileNotFoundError(f"Missing checkpoint: {checkpoint_path}")
        checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=True)
        if checkpoint.get("model_name") != name:
            raise ValueError(f"Checkpoint mismatch for {name}")
        model = create_model(name).to(device)
        model.load_state_dict(checkpoint["model"])
        model.eval()
        loss, accuracy, count = evaluate(model, loader, device)
        row = {"model": name, "dataset": "CIFAR-10 official test", "images": count,
               "test_loss": loss, "test_accuracy": accuracy,
               "parameters": count_parameters(model), "macs_per_image": estimate_macs(model),
               "checkpoint": str(checkpoint_path)}
        rows.append(row)
        print(f"{name}: test_loss={loss:.4f} test_accuracy={accuracy:.4%} "
              f"parameters={row['parameters']:,} MACs={row['macs_per_image']:,}")
    csv_path = output_dir / "cifar10_final_test_summary.csv"
    with csv_path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)
    print(f"saved={csv_path}")


if __name__ == "__main__":
    main()
