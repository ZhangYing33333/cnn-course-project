"""Compare saved checkpoints on the held-out CIFAR-10.1 v6 scenario set."""
import argparse
import csv
import time
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset

from src.models import create_model, count_parameters, estimate_macs

MODELS = ("resnet18", "resnet18_se", "resnet18_dw", "resnet18_gelu")
CLASS_NAMES = ("airplane", "automobile", "bird", "cat", "deer", "dog", "frog", "horse", "ship", "truck")
MEAN = torch.tensor((0.4914, 0.4822, 0.4465)).view(3, 1, 1)
STD = torch.tensor((0.2470, 0.2435, 0.2616)).view(3, 1, 1)


class CIFAR101Dataset(Dataset):
    def __init__(self, root):
        root = Path(root)
        data_path = root / "cifar10.1_v6_data.npy"
        labels_path = root / "cifar10.1_v6_labels.npy"
        if not data_path.is_file() or not labels_path.is_file():
            raise FileNotFoundError(f"Expected CIFAR-10.1 v6 files: {data_path} and {labels_path}")
        self.images = np.load(data_path, allow_pickle=False)
        self.labels = np.load(labels_path, allow_pickle=False).astype(np.int64)
        if self.images.ndim != 4 or self.images.shape[1:] != (32, 32, 3):
            raise ValueError(f"Unexpected image shape {self.images.shape}; expected (N,32,32,3)")
        if self.labels.ndim != 1 or len(self.images) != len(self.labels):
            raise ValueError(f"Images/labels length mismatch: {len(self.images)} vs {len(self.labels)}")
        if self.labels.min() < 0 or self.labels.max() >= len(CLASS_NAMES):
            raise ValueError("Labels must be integer class IDs from 0 through 9")
        self.classes = CLASS_NAMES

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, index):
        image = torch.from_numpy(self.images[index].copy()).permute(2, 0, 1).float().div_(255.0)
        return (image - MEAN) / STD, int(self.labels[index])


def sync(device):
    if device.type == "cuda":
        torch.cuda.synchronize(device)


def main():
    parser = argparse.ArgumentParser(description="Four-model inference comparison on CIFAR-10.1 v6")
    parser.add_argument("--dataset-dir", default="data/cifar10_1")
    parser.add_argument("--output-dir", default="outputs")
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--workers", type=int, default=0)
    parser.add_argument("--device", choices=("auto", "cpu", "cuda"), default="cpu")
    parser.add_argument("--warmup-batches", type=int, default=2)
    args = parser.parse_args()
    if args.batch_size < 1 or args.warmup_batches < 0:
        parser.error("batch-size must be positive and warmup-batches cannot be negative")
    if args.device == "auto":
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    else:
        device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        parser.error("CUDA was requested but is unavailable")

    dataset = CIFAR101Dataset(args.dataset_dir)
    loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=False,
                        num_workers=args.workers, pin_memory=(device.type == "cuda"))
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    summaries, predictions = [], []
    print(f"scenario=low-resource classification dataset=CIFAR-10.1-v6 device={device} images={len(dataset)}")

    for name in MODELS:
        checkpoint_path = output_dir / f"{name}_best.pt"
        if not checkpoint_path.is_file():
            raise FileNotFoundError(f"Missing trained checkpoint: {checkpoint_path}")
        checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=True)
        if checkpoint.get("model_name") != name:
            raise ValueError(f"Checkpoint mismatch for {name}: {checkpoint.get('model_name')}")
        model = create_model(name).to(device)
        model.load_state_dict(checkpoint["model"])
        model.eval()
        correct = total = 0
        elapsed = 0.0
        warmup_images = next(iter(loader))[0].to(device)
        with torch.inference_mode():
            for _ in range(args.warmup_batches):
                model(warmup_images)
            sync(device)
            for batch_index, (images, labels) in enumerate(loader):
                images, labels = images.to(device), labels.to(device)
                sync(device)
                started = time.perf_counter()
                logits = model(images)
                sync(device)
                elapsed += time.perf_counter() - started
                predicted = logits.argmax(1)
                preds, truth = predicted.cpu().tolist(), labels.cpu().tolist()
                for offset, (label, guess) in enumerate(zip(truth, preds)):
                    predictions.append({"model": name, "image_index": batch_index * args.batch_size + offset,
                                        "true_label": CLASS_NAMES[label], "predicted_label": CLASS_NAMES[guess],
                                        "correct": int(label == guess)})
                correct += (predicted == labels).sum().item()
                total += labels.size(0)
        accuracy = correct / total
        params, macs = count_parameters(model), estimate_macs(model)
        avg_ms = elapsed * 1000 / total
        throughput = total / elapsed
        row = {"model": name, "dataset": "CIFAR-10.1-v6", "device": str(device),
               "images": total, "correct": correct, "accuracy": accuracy,
               "avg_inference_ms_per_image": avg_ms,
               "throughput_images_per_second": throughput,
               "parameters": params, "macs_per_image": macs,
               "checkpoint": str(checkpoint_path)}
        summaries.append(row)
        print(f"{name}: accuracy={accuracy:.4%} avg_ms_per_image={avg_ms:.3f} "
              f"images_per_second={throughput:.2f} parameters={params:,} MACs={macs:,}")

    for filename, rows in (("cifar10_1_scene_summary.csv", summaries),
                           ("cifar10_1_scene_predictions.csv", predictions)):
        path = output_dir / filename
        with path.open("w", newline="", encoding="utf-8-sig") as f:
            writer = csv.DictWriter(f, fieldnames=rows[0].keys())
            writer.writeheader()
            writer.writerows(rows)
        print(f"saved={path}")


if __name__ == "__main__":
    main()
